/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package characteranalyzer;
import java.util.Scanner;
/**
 *
 * @author RC_Student_lab
 */
public class CharacterAnalyzer {

    /**
     * @param args the command line arguments
     */
    private static final String [] questions ={
     "Do you often reflect on your emotions and control them calmly?",
     "Do you believe in achieving happiness through reason and wisdom?",
     "Do you often accept situations as they are and adapt to them?",
     "Do you seek knowledge and truth above all else?",
     "Do you practice daily rituals to strengthen your self-discipline?"
            
    };
    private static final int[] stoicResponses={1,0,1,0,1};
    private static final int[] philosopherResponses ={0,1,0,1,0};
    private Stoic stoic;
    private Philosopher philosopher;
    
    //constructor
    public CharacterAnalyzer(){
        stoic = new Stoic();
        philosopher = new Philosopher();
    }
    //Method to analyze responeses
    public void AnalyzeResponses(int []responses){
        for(int i=0;i< responses.length;i++){
            if(responses[i]==stoicResponses[i]){
                stoic.addScore(i);
            }
            if(responses[i]== philosopherResponses[i]){
                philosopher.addScore(i);
            }
        }
    }
    //Method to determine personality type
    public String DeterminePersonality(){
        if(stoic.getScore()>philosopher.getScore()){
            System.out.println("Based on your responeses, you are a stoic!");
        }else if(philosopher.getScore()>stoic.getScore()){
            System.out.println("Based on your responeses, you are a philosopher!");
        }else{
            System.out.println("You have traits of both stoic and philosopher!");
        }
        return null;
    }
    public static void main(String[] args) {

      CharacterAnalyzer Ayanda = new CharacterAnalyzer();
              Scanner AM = new Scanner(System.in);
              int[] responses = new int[questions.length];
              
              System.out.println("Welcome to TAYN:");
              System.out.println("The app that defines WHO WE ARE.");
              System.out.println("-------------------------------------------");
            
              System.out.println("PLease answer the following questions with 1(Yes) or 0(NO)");
              for(int i =0; i< questions.length;i++){
                  System.out.println(questions[i]);
                  responses[i] = AM.nextInt();
              }
              Ayanda.AnalyzeResponses(responses);
              Ayanda.DeterminePersonality();
              AM.close();
    }
    
}
