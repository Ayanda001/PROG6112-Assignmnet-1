/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package characteranalyzer;

/**
 *
 * @author RC_Student_lab
 */
public class PersonalityType {
    protected String name;
    protected int score;
    
    //constructor
    public PersonalityType(String name){
        this.name = name;
        this.score=0; //Intitalize score to 0
    }
    //Method to increment the score
    public void addScore(int value){
        this.score += value;
    }
    //Method to get the score
    public int getScore(){
        return score;
    }
    //Method to get the name
    public String getName(){
        return name;
    }
}
