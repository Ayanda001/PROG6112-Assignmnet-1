/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package characteranalyzer;

/**
 *
 * @author RC_Student_lab
 */
public class Stoic extends PersonalityType {
    //constructor
    public Stoic(){
        super("Stoic");
    }
    
}
