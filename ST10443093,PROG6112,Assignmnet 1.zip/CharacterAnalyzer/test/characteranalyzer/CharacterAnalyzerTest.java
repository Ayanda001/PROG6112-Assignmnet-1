/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package characteranalyzer;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author RC_Student_lab
 */
public class CharacterAnalyzerTest {
    
    public CharacterAnalyzerTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of main method, of class CharacterAnalyzer.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        CharacterAnalyzer.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    /**
     * 
     */
    @Test
    public void testAnalyzeResponses_Stoic() {
        CharacterAnalyzer analyzer = new CharacterAnalyzer();
        
        // Input where user aligns with Stoic responses
        int[] stoicResponses = {1, 0, 1, 0, 1};
        
        analyzer.AnalyzeResponses(stoicResponses);
        String result = analyzer.DeterminePersonality();
        
        assertEquals("Based on your responses, you are a stoic!", result);
    }

    @Test
    public void testAnalyzeResponses_Philosopher() {
        CharacterAnalyzer analyzer = new CharacterAnalyzer();
        
        // Input where user aligns with Philosopher responses
        int[] philosopherResponses = {0, 1, 0, 1, 0};
        
        analyzer.AnalyzeResponses(philosopherResponses);
        String result = analyzer.DeterminePersonality();
        
        assertEquals("Based on your responses, you are a philosopher!", result);
    }

    @Test
    public void testAnalyzeResponses_BothTraits() {
        CharacterAnalyzer analyzer = new CharacterAnalyzer();
        
        // Input where user has traits of both Stoic and Philosopher
        int[] mixedResponses = {1, 1, 1, 1, 1}; // Equal overlap in traits
        
        analyzer.AnalyzeResponses(mixedResponses);
        String result = analyzer.DeterminePersonality();
        
        assertEquals("You have traits of both stoic and philosopher!", result);
    
}
}
