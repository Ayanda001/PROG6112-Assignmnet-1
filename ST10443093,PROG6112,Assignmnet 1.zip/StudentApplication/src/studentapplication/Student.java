/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package studentapplication;
import java.util.ArrayList;
import java.util.Scanner;
/**
 *
 * @author RC_Student_lab
 */
public class Student { 
    
    private String id;
    private String name;
    private int age;
    private String email;
    private String course;

    public static ArrayList<Student> studentList = new ArrayList<>();
    private static Scanner AM = new Scanner(System.in);

    public Student(String id, String name, int age, String email, String course) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.email = email;
        this.course = course;
    }
 public static boolean SearchStudent_StudentNotFound(String studentName) {
        // This will only execute if student if not found
        return false;  // Return true if found, false if not
    }
    // Save student to the list
    public static void SaveStudent() {
        System.out.println("Capture a new student");
        System.out.println("-------------------------");

        System.out.print("Enter the student ID: ");
        String id = AM.nextLine();

        System.out.print("Enter the student name: ");
        String name = AM.nextLine();

        int age = 0;
        boolean validAge = false;
        while (!validAge) {
            try {
                System.out.print("Enter the student age: ");
                age = Integer.parseInt(AM.nextLine());
                if (age >= 16) {
                    validAge = true;
                } else {
                    System.out.println("You have entered an incorrect student age!!! Please re-enter the student age.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input! Please enter a valid age (numbers only).");
            }
        }

        System.out.print("Enter the student email: ");
        String email = AM.nextLine();

        System.out.print("Enter the student course: ");
        String course = AM.nextLine();

        Student newStudent = new Student(id, name, age, email, course);
        studentList.add(newStudent);

        System.out.println("---------------------------------");
        System.out.println("Student details have been successfully saved.");
    }

    // Search for a student by ID
    public static void SearchStudent() {
        System.out.print("Enter the student ID to search: ");
        String searchId = AM.nextLine();

        for (Student student : studentList) {
            if (student.id.equals(searchId)) {
                System.out.println("---------------------------------");
                System.out.println("Student ID: " + student.id);
                System.out.println("Student Name: " + student.name);
                System.out.println("Student Age: " + student.age);
                System.out.println("Student Email: " + student.email);
                System.out.println("Student Course: " + student.course);
                System.out.println("---------------------------------");
                return;
            }
        }
        System.out.println("----------------------------------");
        System.out.println("Student with ID " + searchId + " cannot be located.");
        System.out.println("----------------------------------");
    }

    // Delete a student by ID
    public static void DeleteStudent() {
        System.out.print("Enter the student ID to delete: ");
        String deleteId = AM.nextLine();

        for (Student student : studentList) {
            if (student.id.equals(deleteId)) {
                System.out.print("Are you sure you want to delete student " + deleteId + " from the system? Yes(Y) to delete: ");
                String confirm = AM.nextLine();
                if (confirm.equalsIgnoreCase("Y")) {
                    studentList.remove(student);
                    System.out.println("----------------------------------------------------------------------");
                    System.out.println("Student with ID: " + deleteId + " was deleted!!!");
                    System.out.println("----------------------------------------------------------------------");
                }
                return;
            }
        }
        System.out.println("Student with ID " + deleteId + " cannot be located.");
    }

    // Print student report
    public static void StudentReport() {
        if (studentList.isEmpty()) {
            System.out.println("No students found.");
        } else {
            for (int i = 0; i < studentList.size(); i++) {
                Student student = studentList.get(i);
                System.out.println("Student " + (i + 1));
                System.out.println("Student ID: " + student.id);
                System.out.println("Student Name: " + student.name);
                System.out.println("Student Age: " + student.age);
                System.out.println("Student Email: " + student.email);
                System.out.println("Student Course: " + student.course);
                System.out.println("------------------------");
            }
        }
    }

    // Exit the application
    public static void ExitStudentApplication() {
        System.out.println("Exiting the application...Thank you for using Student Application!!");
        System.exit(0);
    
}
}