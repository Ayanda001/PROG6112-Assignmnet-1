/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package studentapplication;

import java.util.Scanner;
/**
 *
 * @author RC_Student_lab
 */
public class StudentApplication {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         Scanner AM = new Scanner(System.in);
        int choice;

        while (true) {
            System.out.println("Student management application");
            System.out.println("-------------------------------------");
            System.out.print("Enter(1) to launch menu or any other key to exit: ");
            String input = AM.nextLine();

            if (!input.equals("1")) {
                System.out.println("Exiting application...");
                break;
            }

            System.out.println("Please select one of the following menu items:");
            System.out.println("(1) Capture a new student");
            System.out.println("(2) Search for a student");
            System.out.println("(3) Delete a student");
            System.out.println("(4) Print student report");
            System.out.println("(5) Exit Application");
            System.out.print("Enter your choice: ");

            choice = AM.nextInt();
            AM.nextLine();  // Consume newline left-over

            switch (choice) {
                case 1:
                    Student.SaveStudent();
                    break;
                case 2:
                    Student.SearchStudent();
                    break;
                case 3:
                    Student.DeleteStudent();
                    break;
                case 4:
                    Student.StudentReport();
                    break;
                case 5:
                    Student.ExitStudentApplication();
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
            }

            System.out.println("---------------------------------");
            System.out.print("Enter(1) to launch menu or any other key to exit: ");
            input = AM.nextLine();
            if (!input.equals("1")) {
                System.out.println("Exiting application...  Thank you for using StudentApplication:");
                break;
            }
        }
        AM.close();
    }
    
}
