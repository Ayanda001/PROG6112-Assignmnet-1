/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package studentapplication;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author RC_Student_lab
 */
public class StudentTest {
    
    public StudentTest() {
    }
    
    @BeforeAll
    public static void setUpClass() { 
       
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() { 
        
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of SaveStudent method, of class Student.
     */
    @Test
    public void testSaveStudent() {
        System.out.println("SaveStudent");
        Student.SaveStudent();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test executes.");
    }

    /**
     * Test of SearchStudent method, of class Student.
     */
    @Test
    public void testSearchStudent() {
        System.out.println("SearchStudent");
        Student.SearchStudent();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test executes.");
    }
    /**
     * Test of SearchStudent_StudentNotFound in SearchStudent method of student class
     */
    @Test
    public void testSearchStudent_StudentNotFound(){
        System.out.println("Testing: Student not found.");

        // Example of searching for a student that doesn't exist
        String studentName = "NonExistentStudent";
        
        // Assuming `SearchStudent` returns a boolean or similar value
        boolean result = Student.SearchStudent_StudentNotFound(studentName);
        
        // Check if the result matches the expected behavior when student is not found
        assertFalse(result, "Student should not be found.");    }

    /**
     * Test of DeleteStudent method, of class Student.
     */
    @Test
    public void testDeleteStudent() {
        System.out.println("DeleteStudent");
        Student.DeleteStudent();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test executes.");
    }
/**
 * Test of DeleteStudent_StudentNotFound
 */
    @Test
    public void testDeleteStudent_StudentNotFound(){
         System.out.println("Testing: Student not found.");

        // Example of deleting for a student that doesn't exist
        String studentName = "NonExistentStudent";
        
        // Assuming `DeleteStudent` returns a boolean or similar value
        boolean result = Student.SearchStudent_StudentNotFound(studentName);
        
        // Check if the result matches the expected behavior when student is not found
        assertFalse(result, "Student should not be found.");    
    }
    /**
     * Test of StudentAge_StudentAgeValid of StudentAge method of student class
     */
    public void testStudentAge_StudentAgeValid(){
        System.out.println("Test age of student");
    }
    /**
     * Test of StudentAge_StudentAgeInvalid of StudentAge method of student class
     */
    @Test
    public void testStudentAge_StudentAgeInvalid(){
        System.out.println("Age is Invalid");
    }
    /**
     * Test of StudentAge_StudentAgeInvalidCharacter of StudentAge of student class
     */
    @Test
    public void testStudentAge_StudentAgeInvalidCharacter(){
        System.out.println("Invalid character use");
    }
    /**
     * Test of StudentReport method, of class Student.
     */
    @Test
    public void testStudentReport() {
        System.out.println("StudentReport");
        Student.StudentReport();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test executes.");
    }

    /**
     * Test of ExitStudentApplication method, of class Student.
     */
    @Test
    public void testExitStudentApplication() {
        System.out.println("ExitStudentApplication");
        Student.ExitStudentApplication();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test executes.");
    }
    /**
     * Test 
     */
}
